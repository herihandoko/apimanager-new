-- Database initialization script for API Manager
-- This script creates the database and sets up initial permissions

-- Create database if it doesn't exist
SELECT 'CREATE DATABASE apimanager'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'apimanager')\gexec

-- Connect to the apimanager database
\c apimanager;

-- Create extensions if they don't exist
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON DATABASE apimanager TO apimanager_user;
GRANT ALL PRIVILEGES ON SCHEMA public TO apimanager_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO apimanager_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO apimanager_user;

-- Set default privileges for future objects
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO apimanager_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO apimanager_user;

-- Create indexes for better performance (these will be created by Prisma, but we can add custom ones here)
-- CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
-- CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
-- CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(key);
-- CREATE INDEX IF NOT EXISTS idx_api_logs_created_at ON api_logs(created_at);
-- CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);

-- Set timezone
SET timezone = 'UTC';

-- Log successful initialization
SELECT 'Database initialization completed successfully' as status; 