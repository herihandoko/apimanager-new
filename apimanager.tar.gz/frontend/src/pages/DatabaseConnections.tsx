import React from 'react';
import DatabaseConnectionsList from '@/components/database-connections/DatabaseConnectionsList';

export default function DatabaseConnections() {
  return <DatabaseConnectionsList />;
} 