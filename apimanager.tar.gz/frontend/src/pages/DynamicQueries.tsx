import React from 'react';
import DynamicQueriesList from '@/components/dynamic-queries/DynamicQueriesList';

export default function DynamicQueries() {
  return <DynamicQueriesList />;
} 