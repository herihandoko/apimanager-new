-- AlterTable
ALTER TABLE "audit_logs" ADD COLUMN     "severity" TEXT NOT NULL DEFAULT 'low',
ADD COLUMN     "status" TEXT NOT NULL DEFAULT 'success';
